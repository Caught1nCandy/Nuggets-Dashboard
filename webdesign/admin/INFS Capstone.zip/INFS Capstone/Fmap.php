
<html>
<head>
<title> Private Home </title>
<link rel="stylesheet" href="FPriv.css"> 
</head>
<body>

<div class="navbar">
  <a href="Fprivhome.php">Employee Search</a>
  <a href="Fmap.php">Maps</a>
  <a href="Fevent.php">Events</a>
  <a href="Fdrill.php">Drill Down</a>
  <a href="Frequest.php">Update Request</a>
</div>

<img src="fimg/eemap.jpg" width="1275">
<img src="fimg/emap.jpg" width="1275">


</body>
</html>