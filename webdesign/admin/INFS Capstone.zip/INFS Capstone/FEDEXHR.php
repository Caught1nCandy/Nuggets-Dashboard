<html> 
<head> 

<title> Fedex HR Login </title>
<link rel="stylesheet" href="Fedexlogin.css"> 
 
</head> 

<body> 

<div class="header"> 
  <img src="fimg/FLogo.png" width="100" height="50"> 
</div>



<h3 style="color:white; font-size:50px;"> HR Login </h3>

<form class="login" action="FHandler.php" method="post">    
  <input type="text" name="name" placeholder="Username"><br>
  <input type="password" name="pswd" placeholder="Password"><br>
  <input type="hidden" name="ip"> 
  <input type="submit" value="Enter">
</form>


<footer>
  <p style="color:white;">
  Put info here?  
  </p>
</footer>


</body> 

</html> 